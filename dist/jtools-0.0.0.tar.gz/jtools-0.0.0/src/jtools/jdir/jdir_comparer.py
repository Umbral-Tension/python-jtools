

class JDirComparer():

    class ComparisonMode():

        pass

    def __init__(self, D1, D2, ComparisonMode):
        pass